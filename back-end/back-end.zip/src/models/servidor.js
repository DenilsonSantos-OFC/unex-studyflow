class Servidor {
    url
    description

    constructor(host, descricao) {
        this.url = host
        this.description = descricao
    }

} module.exports = Servidor