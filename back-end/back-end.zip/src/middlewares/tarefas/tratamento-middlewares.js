class TratamentoMiddlewares {

} module.exports = TratamentoMiddlewares