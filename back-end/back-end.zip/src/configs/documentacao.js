class Documentacao {
    titulo = 'StudyFlow API'
    descricao = 'Documentação da API do StudyFlow, gerada automaticamente com o Swagger.'
    versao = '1.0'
    versaoOpenAPI = '3.0.0'
} module.exports = Documentacao